

#ifndef _CAPI_H_
#define _CAPI_H_

#include "capi-variable-type.h"
//#include "capi-app-mgr.h"
//#include "capi-dbus-service.h"
#include "capi-sys-service.h"
//#include "ctsgw.h"

#endif
