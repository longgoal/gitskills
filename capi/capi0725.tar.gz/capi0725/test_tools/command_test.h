#include <gio/gio.h>
typedef enum
{
    TS_TYPE_API ,
    TS_TYPE_MGR ,
    
} test_type_t;

int Get_mode(gchar* command);
