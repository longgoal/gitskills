#include "result_check_util.h"


gboolean Check_return_result(int ret,int tar){

}

gboolean    CheckCtSgwObjPath_t(CtSgwObjPath_t *result ,CtSgwObjPath_t *target ){

}

gboolean    CheckCtSgwDeviceInfo_t(CtSgwDeviceInfo_t *result ,CtSgwDeviceInfo_t *target ){

}

