#include <gio/gio.h>

//#include "capi.h"



int start(gchar *command);
int Process_test_single();
int Process_test_module();
int Process_test_all();
cJSON*  dofile(char *filename);
